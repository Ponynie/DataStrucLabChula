package lab;
import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

import datastr.SeparateChainingHashMap;
//Q1
public class Main {
    public static void main(String[] args) throws Exception {
        File file = new File("register.csv");
        SeparateChainingHashMap studentTable = new SeparateChainingHashMap(16);
        try (Scanner sc = new Scanner(file)) {
            while (sc.hasNextLine()) {
                String[] data = sc.nextLine().split(",");
                for (int i = 0 ; i < data.length ; i++) data[i] = data[i].trim();
                Student st = new Student(data[0], data[1], data[2]);
                CourseGrade cg = new CourseGrade(data[3], data[4], Integer.parseInt(data[5]), Integer.parseInt(data[6]), Integer.parseInt(data[7]), Float.parseFloat(data[8]));
                if (studentTable.get(st) != null) ((ArrayList<CourseGrade>) studentTable.get(st)).add(cg);
                else {
                    ArrayList<CourseGrade> cgList = new ArrayList<CourseGrade>();
                    cgList.add(cg);
                    studentTable.put(st, cgList);
                }
            }
            System.out.println(studentTable.toString());
        }
    }
}