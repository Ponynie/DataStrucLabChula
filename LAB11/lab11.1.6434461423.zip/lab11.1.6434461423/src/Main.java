public class Main {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
        int[] arr = {-20,-9,-32,-6,-15,25,-50,-5,-8,-13,18};
        Heap huh = new Heap(arr);
        huh.printHeap();
    }
}
