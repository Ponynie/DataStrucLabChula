public class Main {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
        int[] listA ={15,9,7,16,31,2,20,25,17,12};
        QuickSort qs = new QuickSort();
        qs.sort(listA);
        printArray(listA);
        System.out.println();
        int[] listB ={5,2,12,9,1,8,7,18};
        MergeSort mergeSort = new MergeSort(listB);
        mergeSort.mergeS();
        mergeSort.printS();
    }
    public static void printArray(int[] array) {
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + ",");
        }
    }
}
